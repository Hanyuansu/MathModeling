# -*- coding: utf-8 -*-
"""
Q3 时间轴绘图（two_stage）
- 仅时间轴函数 + 按你提供的 Q3 结果进行调用
- 保存到 result/Problem3_result/Q3_two_stage_遮掩时长.png
"""
import matplotlib.pyplot as plt
plt.rcParams['font.family'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False

# -*- coding: utf-8 -*-
"""
Q3 时间轴（含“投放/起爆”标记）
- 灰条：有效窗口
- 红条：遮掩并集区间
- 竖线：投放(--) 与 起爆(:) 事件，默认锚定到“第一个投放时刻 +20s”的窗口，
        因而最左边一根竖线 = 第一个烟雾弹的投放数据（t_drop[0]）。

作者：ChatGPT
"""

import os
from typing import List, Tuple, Sequence

# -*- coding: utf-8 -*-
import os
from typing import List, Tuple, Sequence

def plot_cover_timeline(
    intervals: List[Tuple[float, float]],
    *,
    xlim: Tuple[float, float],
    # --- 事件标记（可选） ---
    vlines_drop: Sequence[float] | None = None,   # 各次“投放”时刻
    vlines_burst: Sequence[float] | None = None,  # 各次“起爆”时刻
    show_drop_labels: bool = True,
    show_burst_labels: bool = True,
    drop_label_prefix: str = "投放",
    burst_label_prefix: str = "起爆",
    drop_linestyle: str = "--",
    burst_linestyle: str = ":",
    drop_color: str = "tab:blue",
    burst_color: str = "tab:orange",

    # --- 竖排文字控制（新增） ---
    drop_text_rotation: float = 90.0,   # 投放标签旋转角度（90=竖排）
    burst_text_rotation: float = 90.0,  # 起爆标签旋转角度（90=竖排）
    text_y: float = 1.19,               # 文本纵向位置（相对轴域）
    text_fontsize: int = 9,

    # --- 外观参数 ---
    title: str | None = None,           # 显式标题（例： "M1  总遮蔽时长=6.16 s"）
    title_prefix: str = "M1",
    show_total: bool = False,           # 若 title=None 时，是否自动在标题中附上总遮蔽时长
    figsize=(8.6, 2.0),
    bg_color="#dddddd",
    fg_color="tab:red",
    bg_lw=10,
    fg_lw=10,
    xlabel="t / s",

    # --- 图例移到外面（新增） ---
    legend_outside: bool = True,        # True = 图外右侧；False = 图内
    legend_loc_inside: str = "upper right",   # 图内时用
    legend_bbox: Tuple[float, float] = (1.02, 1.0),  # 图外位置 (x,y)，相对轴域
    legend_loc_outside: str = "upper left",

    save_path: str | None = None,
    dpi=180,
    transparent=False,
    pad_inches=0.05,
    show=True,
    close=False,
    return_fig_ax: bool = False,
):
    """
    绘制“起爆窗口内的遮掩时间轴”，并叠加“投放/起爆”竖线 + 竖排文字标注。
    """
    import matplotlib.pyplot as plt

    # 中文字体（可选）
    try:
        plt.rcParams['font.family'] = 'SimHei'
        plt.rcParams['axes.unicode_minus'] = False
    except Exception:
        pass

    t0, t1 = xlim
    total_cover = float(sum(max(0.0, b - a) for (a, b) in intervals))
    if title is None:
        title = f"{title_prefix}  总遮蔽时长={total_cover:.3f} s" if show_total else f"{title_prefix}"

    fig, ax = plt.subplots(figsize=figsize, constrained_layout=True)
    y = 1.0

    # 背景有效窗口
    ax.hlines(y, t0, t1, color=bg_color, lw=bg_lw, label="有效窗口")

    # 遮掩区间
    for (a, b) in intervals:
        aa, bb = max(a, t0), min(b, t1)
        if bb > aa:
            ax.hlines(y, aa, bb, color=fg_color, lw=fg_lw, label="遮掩段")

    # --- 事件竖线（只画落在窗口内的） ---
    def _draw_vlines(xs: Sequence[float] | None, ls: str, col: str, label: str):
        if not xs:
            return []
        xs_in = [x for x in xs if (t0 <= x <= t1)]
        if not xs_in:
            return []
        h0, h1 = 0.84, 1.16  # 竖线高度略高于灰条
        first = True
        for x in xs_in:
            ax.vlines(x, h0, h1, linestyles=ls, colors=col, lw=1.8,
                      label=(label if first else None))
            first = False
        return sorted(xs_in)

    xs_drop_in  = _draw_vlines(vlines_drop,  drop_linestyle,  drop_color,  "投放")
    xs_burst_in = _draw_vlines(vlines_burst, burst_linestyle, burst_color, "起爆")



    # 坐标轴与标题（抬高上沿以容纳竖排文字）
    ax.set_xlim(t0, t1)
    ax.set_ylim(0.8, 1.30)
    ax.set_yticks([])
    ax.set_xlabel(xlabel)
    ax.set_title(title)

    # 去重图例
    handles, labels = ax.get_legend_handles_labels()
    uniq = dict(zip(labels, handles))

    if legend_outside:
        ax.legend(
            uniq.values(), uniq.keys(),
            loc=legend_loc_outside, bbox_to_anchor=legend_bbox,
            borderaxespad=0.0, fontsize=9
        )
    else:
        ax.legend(uniq.values(), uniq.keys(), loc=legend_loc_inside, fontsize=9)

    # 保存/展示（图外图例时，tight 以防裁切）
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=dpi, transparent=transparent,
                    pad_inches=pad_inches, bbox_inches="tight")
        print(f"[OK] 已保存：{save_path}")
    if show:
        plt.show()
    if close:
        plt.close(fig)
    if return_fig_ax:
        return fig, ax



# =========================
# Q3 | two_stage — 你的数据
# =========================
if __name__ == "__main__":
    out_dir = os.path.join("result", "Problem3_result")

    # 并集遮掩区间
    intervals_Q3 = [(1.2, 7.36)]

    # 三次投放与起爆（单位：秒）
    drops  = [0.0, 1.0, 25.654]
    bursts = [0.2, 1.2, 25.854328299370056]

    # —— 窗口锚定到“第一个投放” —— 保证“最左边=投放1”
    #    比例与第一问一致（+20 s），因此第三次(≈25.85 s)会在窗口外看不到；
    #    若要把第三次也纳入，可把 t0 改成 0.0，t1 改成 30.0 或用 max(bursts)+若干裕量。
    t0 = drops[0]                 # = 0.0（第一个投放）
    xlim_Q3 = (t0, t0 + 20.0)     # [0.0, 20.0]

    plot_cover_timeline(
        intervals_Q3,
        xlim=xlim_Q3,
        vlines_drop=drops,
        vlines_burst=bursts,
        title="M1  总遮蔽时长=6.16 s",
        figsize=(8.6, 2.0),
        bg_color="#dddddd",
        fg_color="tab:red",
        bg_lw=10,
        fg_lw=10,
        save_path=os.path.join(out_dir, "遮掩时长.png"),
        dpi=180,
        transparent=False,
        pad_inches=0.05,
        show=True,
        close=False
    )

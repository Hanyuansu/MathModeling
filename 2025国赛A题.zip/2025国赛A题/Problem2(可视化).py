# -*- coding: utf-8 -*-
"""
Q2 时间轴绘图（仅时间轴函数 + 与给定最优解一致的参数调用）
作者：ChatGPT

功能说明：
- plot_cover_timeline(): 绘制“有效窗口（灰条）+ 遮掩区间（红条）”的时间轴；
- 本文件下方使用你提供的 Q2 结果（L1 / two_stage）调用该函数并保存图片。

使用方法：
1) 直接运行本文件（或将函数与调用粘到你的工程里运行）；
2) 图片将保存到 result/Problem2_result/ 目录。
"""

import os
from typing import List, Tuple
import matplotlib.pyplot as plt
plt.rcParams['font.family'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False
def plot_cover_timeline(
    intervals: List[Tuple[float, float]],
    *,
    xlim: Tuple[float, float],
    title: str = None,
    title_prefix: str = "M1",
    show_total: bool = False,
    figsize=(8.6, 2.0),
    bg_color="#dddddd",
    fg_color="tab:red",
    bg_lw=10,
    fg_lw=10,
    xlabel="t / s",
    legend_loc="upper right",
    save_path: str | None = None,
    dpi=180,
    transparent=False,
    pad_inches=0.05,
    show=True,
    close=False,
    return_fig_ax: bool = False
):
    """
    绘制遮掩时间轴（与第一问同思路、同参数风格）。

    参数
    ----
    intervals : [(a, b), ...]
        遮掩区间（单位：秒）。例如 [(0.869, 5.929)]。
    xlim : (t0, t1)
        显示窗口（单位：秒），通常取 (t_burst, t_burst+20.0) 保持比例一致。
    title : str | None
        标题。若传入则完全按该标题显示（用来严格匹配“总遮蔽时长=5.060 s”等文案）。
    title_prefix : str
        若未传 title 且 show_total=True，则标题会自动生成为 "{title_prefix}  总遮蔽时长=xx.xxx s"。
    show_total : bool
        是否在自动标题中显示总遮蔽时长（仅当 title=None 时生效）。
    其余参数：
        figsize, 颜色、线宽、图例位置、保存参数等，均与第一问保持一致。

    理论要点（简述）
    --------------
    - 时间轴以“有效窗口”为背景（灰条），遮掩发生的时间段覆盖其上（红条）；
    - 锁定 xlim = (t_burst, t_burst + 20.0) 可保证各方案/策略“同尺度可比”，
      这是评审/复现实验图时非常关键的一点（比例一致）。
    """
    import matplotlib.pyplot as plt

    t0, t1 = xlim
    # 计算总遮掩时长（用于可选的自动标题）
    total_cover = float(sum(max(0.0, b - a) for (a, b) in intervals))

    # 标题：若未指定 title，可选择是否自动附上总时长
    if title is None:
        title = f"{title_prefix}  总遮蔽时长={total_cover:.3f} s" if show_total else f"{title_prefix}"

    # 开画
    fig, ax = plt.subplots(figsize=figsize, constrained_layout=True)
    y = 1.0

    # 背景有效窗口（灰色粗线）
    ax.hlines(y, t0, t1, color=bg_color, lw=bg_lw, label="有效窗口")

    # 遮掩区间（红色粗线）
    for (a, b) in intervals:
        aa = max(a, t0)
        bb = min(b, t1)
        if bb > aa:
            ax.hlines(y, aa, bb, color=fg_color, lw=fg_lw, label="遮掩段")

    # 坐标轴与外观
    ax.set_xlim(t0, t1)
    ax.set_ylim(0.8, 1.2)
    ax.set_yticks([])
    ax.set_xlabel(xlabel)
    ax.set_title(title)

    # 去重图例
    handles, labels = ax.get_legend_handles_labels()
    uniq = dict(zip(labels, handles))
    ax.legend(uniq.values(), uniq.keys(), loc=legend_loc, fontsize=9)

    # 保存
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=dpi, transparent=transparent, pad_inches=pad_inches)
        print(f"[OK] 已保存：{save_path}")

    # 展示/关闭
    if show:
        plt.show()
    if close:
        plt.close(fig)

    if return_fig_ax:
        return fig, ax


# =========================
# 使用你的“Q2最优解”参数绘图
# =========================
if __name__ == "__main__":
    out_dir = os.path.join("result", "Problem2_result")



    # --- [Q2 | two_stage] ---
    t_burst_TS = 0.869068730035006
    intervals_TS = [(0.869068730035006, 5.929068730035007)]   # 与你结果完全一致
    plot_cover_timeline(
        intervals_TS,
        xlim=(t_burst_TS, t_burst_TS + 20.0),           # 固定窗口，保证与第一问同比例
        title="M1  总遮蔽时长=5.060 s",                  # 精确文案
        figsize=(8.6, 2.0),
        bg_color="#dddddd",
        fg_color="tab:red",
        bg_lw=10,
        fg_lw=10,
        save_path=os.path.join(out_dir, "遮掩时长.png"),
        dpi=180,
        transparent=False,
        pad_inches=0.05,
        show=True,
        close=False
    )

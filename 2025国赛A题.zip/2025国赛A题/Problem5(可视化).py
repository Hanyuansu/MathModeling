# -*- coding: utf-8 -*-
"""
Q5 遮掩时长时间轴图
- 每个导弹单独画一条时间轴
- 灰条：有效窗口 (起爆 ~ T_hit)
- 红条：遮掩区间
- 蓝虚线：投放时刻
- 橙点划线：起爆时刻
- 图例移到外侧
"""

import os
import matplotlib.pyplot as plt
from typing import List, Tuple, Dict, Any
plt.rcParams['font.family'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False

def plot_cover_timeline_multi(per_missile: List[Dict[str, Any]],
                              *,
                              drops: List[float],
                              bursts: List[float],
                              title: str = None,
                              figsize=(9, 3),
                              save_path=None,
                              dpi=180):
    """
    多导弹遮掩时间轴图

    per_missile: 列表，每个元素形如：
        {
          'missile': 'M1',
          'T_hit': float,
          'cover_s': float,
          'intervals': [(a,b), ...]
        }
    drops: 全部投放时刻
    bursts: 全部起爆时刻
    """
    fig, ax = plt.subplots(figsize=figsize, constrained_layout=True)

    # 设置字体
    try:
        plt.rcParams['font.family'] = 'SimHei'
        plt.rcParams['axes.unicode_minus'] = False
    except:
        pass

    # 每个导弹单独一行
    y_base = 1.0
    y_gap = 0.5

    colors = ["tab:red", "tab:green", "tab:purple"]  # 三个导弹红/绿/紫区分
    for idx, info in enumerate(per_missile):
        y = y_base - idx * y_gap
        missile = info["missile"]
        T_hit = info["T_hit"]
        intervals = info["intervals"]
        total_cover = info["cover_s"]

        # 有效窗口（灰条：从第一个区间开始到 T_hit）
        t0 = min(a for a, _ in intervals)
        ax.hlines(y, t0, T_hit, color="#dddddd", lw=8, label="有效窗口" if idx == 0 else None)

        # 遮掩区间（红/绿/紫）
        for (a, b) in intervals:
            ax.hlines(y, a, b, color=colors[idx % len(colors)], lw=8,
                      label=f"{missile}遮掩段" if idx == 0 else None)

        # 投放竖线
        for j, d in enumerate(drops):
            if t0 <= d <= T_hit:
                ax.axvline(d, color="tab:blue", ls="--", lw=1.5,
                           label="投放" if (idx == 0 and j == 0) else None)

        # 起爆竖线
        for j, b in enumerate(bursts):
            if t0 <= b <= T_hit:
                ax.axvline(b, color="tab:orange", ls=":", lw=1.5,
                           label="起爆" if (idx == 0 and j == 0) else None)

        # 标题在左边标出导弹名与遮蔽时长
        ax.text(t0 - 1.0, y, f"{missile} ({total_cover:.2f}s)", ha="right", va="center", fontsize=9)

    ax.set_xlabel("t / s")
    if title:
        ax.set_title(title)

    # y 轴不需要
    ax.set_yticks([])
    ax.set_ylim(y_base - (len(per_missile) - 1) * y_gap - 0.3, y_base + 0.3)

    # 图例放外面
    handles, labels = ax.get_legend_handles_labels()
    uniq = dict(zip(labels, handles))
    ax.legend(uniq.values(), uniq.keys(),
              loc="upper left", bbox_to_anchor=(1.02, 1.0),
              borderaxespad=0.0, fontsize=9)

    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=dpi, bbox_inches="tight")
        print(f"[OK] 已保存：{save_path}")
    plt.show()


# =========================
# 用你的 Q5 数据绘图
# =========================
if __name__ == "__main__":
    out_dir = os.path.join("result", "Problem5_result")

    per_missile = [
        {"missile": "M1", "T_hit": 66.999, "cover_s": 20.1,
         "intervals": [(3.75, 9.81), (15.045, 23.895), (30.75, 35.895)]},
        {"missile": "M2", "T_hit": 63.75, "cover_s": 4.41,
         "intervals": [(10.935, 15.33)]},
        {"missile": "M3", "T_hit": 60.366, "cover_s": 3.72,
         "intervals": [(23.25, 26.955)]},
    ]

    # 所有投放、起爆时刻（从 selected 和 bursts 提取）
    drops  = [12.315, 10.725, 22.995, 24.075, 1.395, 3.045, 0.0, 2.46, 9.24,
              10.875, 1.785, 5.58, 11.085, 5.58, 7.095]
    bursts = [14.977, 10.925, 23.246, 25.047, 5.598, 15.045, 3.739, 2.932,
              9.688, 11.14, 1.997, 6.522, 11.367, 6.272, 7.417]

    plot_cover_timeline_multi(
        per_missile,
        drops=drops,
        bursts=bursts,
        title=" 总遮蔽时长=28.23 s",
        save_path=os.path.join(out_dir, "遮掩时长.png")
    )
